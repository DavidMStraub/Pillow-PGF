var classCWaveletTransform =
[
    [ "CWaveletTransform", "classCWaveletTransform.html#aaa781fda53530e8c4d4057335ef320cb", null ],
    [ "~CWaveletTransform", "classCWaveletTransform.html#a222dd983545e969ed5faf32448020f1f", null ],
    [ "Destroy", "classCWaveletTransform.html#a72c1bc79111534886187fcf2ac4cebea", null ],
    [ "ForwardRow", "classCWaveletTransform.html#a7c82d85117e367c8302b2e4681db138d", null ],
    [ "ForwardTransform", "classCWaveletTransform.html#a7278418accd9329b9264ebe5f584001f", null ],
    [ "GetSubband", "classCWaveletTransform.html#a347b59b1d7bc18de9294c714afac7ddf", null ],
    [ "InitSubbands", "classCWaveletTransform.html#a4d03868a4bb8688235d41d6b1d7a97de", null ],
    [ "InterleavedToSubbands", "classCWaveletTransform.html#a7e926fe30c00e2bfa23f00a28a393f43", null ],
    [ "InverseRow", "classCWaveletTransform.html#a1a39a469fd695c50efc42d744689982d", null ],
    [ "InverseTransform", "classCWaveletTransform.html#a26a70797c2a0db893876b75d131f420c", null ],
    [ "SubbandsToInterleaved", "classCWaveletTransform.html#a415837709c90ed360a8415a6463a3e29", null ],
    [ "CSubband", "classCWaveletTransform.html#abdf6119f0e2b50fd156b12b231e929e7", null ],
    [ "m_nLevels", "classCWaveletTransform.html#ad8c2d96ff3e7125da10de8785631460a", null ],
    [ "m_subband", "classCWaveletTransform.html#a0116d5d57b09e2c9f19776531dbc20f7", null ]
];