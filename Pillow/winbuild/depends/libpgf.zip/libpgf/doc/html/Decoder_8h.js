var Decoder_8h =
[
    [ "CDecoder", "classCDecoder.html", "classCDecoder" ],
    [ "CMacroBlock", "classCDecoder_1_1CMacroBlock.html", "classCDecoder_1_1CMacroBlock" ],
    [ "BufferLen", "Decoder_8h.html#a309eafbca7ed5953ef9102861479f4ed", null ],
    [ "CodeBufferLen", "Decoder_8h.html#a05a74e73e6c734fcad194efbca053ed5", null ]
];