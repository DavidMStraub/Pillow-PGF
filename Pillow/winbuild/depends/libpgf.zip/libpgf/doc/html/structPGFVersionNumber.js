var structPGFVersionNumber =
[
    [ "PGFVersionNumber", "structPGFVersionNumber.html#a4293f51debdbadd08f42775d0322275f", null ],
    [ "major", "structPGFVersionNumber.html#a382f48922a9135e41e53f60e28815af2", null ],
    [ "week", "structPGFVersionNumber.html#a4391fcda3b38f0514dff17ea5c0ea81e", null ],
    [ "year", "structPGFVersionNumber.html#ab4eaf66cd93fcf46b5dcc06dbe44837f", null ]
];