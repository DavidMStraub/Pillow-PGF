var searchData=
[
  ['read',['Read',['../classCPGFImage.html#a4a1d49cdf9da6934381bb25332d85ccf',1,'CPGFImage::Read(int level=0, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFImage.html#ad25f535f946f5a711576d6b28774cbb9',1,'CPGFImage::Read(PGFRect &amp;rect, int level=0, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFStream.html#afdc81fe9b4d2d962b8112e50eace95a2',1,'CPGFStream::Read()'],['../classCPGFFileStream.html#a3ff32003518e1d996cc8af33c5bbbfaf',1,'CPGFFileStream::Read()'],['../classCPGFMemoryStream.html#a4cf0499309d901fcdcd9282a7351d24d',1,'CPGFMemoryStream::Read()']]],
  ['readbuffer',['ReadBuffer',['../classCSubband.html#ad32cf00a5ee6a65573bcacd440308673',1,'CSubband']]],
  ['readencodeddata',['ReadEncodedData',['../classCPGFImage.html#a570d1d1072cdd3e24b838c066abc8da3',1,'CPGFImage::ReadEncodedData()'],['../classCDecoder.html#a4146a0adddfe52ca79de8b0be58e8482',1,'CDecoder::ReadEncodedData()']]],
  ['readencodedheader',['ReadEncodedHeader',['../classCPGFImage.html#a55a27e09a6bcd1bca6d57335956dc76c',1,'CPGFImage']]],
  ['readmacroblock',['ReadMacroBlock',['../classCDecoder.html#a55cbccabab76500fd47e15332d6b6506',1,'CDecoder']]],
  ['readpreview',['ReadPreview',['../classCPGFImage.html#a126846c7265783e14da0f4dde6c9346b',1,'CPGFImage']]],
  ['reconstruct',['Reconstruct',['../classCPGFImage.html#abf906b469e11800e819db00009255b90',1,'CPGFImage']]],
  ['reinitialize',['Reinitialize',['../classCPGFMemoryStream.html#afb1145a071e4156a4343c6203ad18b0c',1,'CPGFMemoryStream']]],
  ['resetstreampos',['ResetStreamPos',['../classCPGFImage.html#a7df11c06be23e14f83c9aa343f1204d0',1,'CPGFImage']]],
  ['rgbtoyuv',['RgbToYuv',['../classCPGFImage.html#a7a870dea53390ffe1af210069f6b30eb',1,'CPGFImage']]],
  ['rlesigns',['RLESigns',['../classCEncoder_1_1CMacroBlock.html#a50637f0c6ccc3d29b10063204a55253b',1,'CEncoder::CMacroBlock']]],
  ['roiblockheader',['ROIBlockHeader',['../unionROIBlockHeader.html#aa831264ba94e20471457cf33d0372443',1,'ROIBlockHeader::ROIBlockHeader(UINT16 v)'],['../unionROIBlockHeader.html#aa3641f52d4bf3a1f5eafee97e64e5c4e',1,'ROIBlockHeader::ROIBlockHeader(UINT32 size, bool end)']]],
  ['roiissupported',['ROIisSupported',['../classCPGFImage.html#a9db775cf3a36997b55106fbab7284c14',1,'CPGFImage']]]
];
