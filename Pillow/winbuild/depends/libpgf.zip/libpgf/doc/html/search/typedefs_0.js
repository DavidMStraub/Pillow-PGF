var searchData=
[
  ['datat',['DataT',['../PGFtypes_8h.html#acb1ee3f52ccfad782dcaa0abd79e5d05',1,'PGFtypes.h']]]
];
