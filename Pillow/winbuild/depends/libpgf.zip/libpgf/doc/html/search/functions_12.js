var searchData=
[
  ['version',['Version',['../classCPGFImage.html#aa872f5010f55a3bc696706d259b52051',1,'CPGFImage']]]
];
