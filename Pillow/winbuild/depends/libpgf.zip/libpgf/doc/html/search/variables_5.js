var searchData=
[
  ['left',['left',['../structPGFRect.html#ac3472e1dc20bc4b1584058376fd7b989',1,'PGFRect']]]
];
