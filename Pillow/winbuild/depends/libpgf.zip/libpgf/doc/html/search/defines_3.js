var searchData=
[
  ['datatsize',['DataTSize',['../PGFtypes_8h.html#adbb49c2b6ab931f68f08a8dc1141727d',1,'PGFtypes.h']]],
  ['downsamplethreshold',['DownsampleThreshold',['../PGFtypes_8h.html#ac3fdd6d7d71ed50f3b7365d5bc287cda',1,'PGFtypes.h']]],
  ['dwwidth',['DWWIDTH',['../PGFplatform_8h.html#ac0b68f6649b541591637d4a0c3801411',1,'PGFplatform.h']]],
  ['dwwidthbits',['DWWIDTHBITS',['../PGFplatform_8h.html#a5e4b038d49a5b8169c4af56c80ee5ac2',1,'PGFplatform.h']]],
  ['dwwidthrest',['DWWIDTHREST',['../PGFplatform_8h.html#adb44cec3b215759869d8e41b02ebaf6d',1,'PGFplatform.h']]]
];
