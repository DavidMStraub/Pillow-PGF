var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwy~",
  1: "cipr",
  2: "bdepsw",
  3: "abcdefghilmnopqrsuvw~",
  4: "bcefhlmnqrtuvwy",
  5: "dr",
  6: "opu",
  7: "hlpu",
  8: "c",
  9: "_bcdhilmnprsvwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

