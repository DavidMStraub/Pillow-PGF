var searchData=
[
  ['usedbitsperchannel',['usedBitsPerChannel',['../structPGFHeader.html#abddcc9ee6e17690986cf77a6d16aceb6',1,'PGFHeader']]],
  ['userdata',['userData',['../structPGFPostHeader.html#aeeb6e57e8343eb3d42406f0baf3ae6e1',1,'PGFPostHeader']]],
  ['userdatalen',['userDataLen',['../structPGFPostHeader.html#a0fb630d6cd14ed865dd5fe20227279f2',1,'PGFPostHeader']]]
];
