var searchData=
[
  ['quality',['quality',['../structPGFHeader.html#ac314a16d5984aea88f4a5ff38f49c08b',1,'PGFHeader']]]
];
