var searchData=
[
  ['headersize',['HeaderSize',['../PGFtypes_8h.html#a36882df0caa9057f3144aeb429a2d468',1,'PGFtypes.h']]]
];
