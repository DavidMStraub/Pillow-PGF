var searchData=
[
  ['open',['Open',['../classCPGFImage.html#adbe9092b915a2c5b2361f4db186b991c',1,'CPGFImage']]],
  ['orientation',['Orientation',['../PGFtypes_8h.html#a871118a09520247c78a71ecd7b0abd58',1,'PGFtypes.h']]]
];
