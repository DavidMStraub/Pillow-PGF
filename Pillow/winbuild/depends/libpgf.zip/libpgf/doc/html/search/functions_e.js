var searchData=
[
  ['quality',['Quality',['../classCPGFImage.html#a6d8ca06237591aae49d7f25278067c63',1,'CPGFImage']]],
  ['quantize',['Quantize',['../classCSubband.html#a5de71c37eb00e5e5dad3fe5e38b81ced',1,'CSubband']]]
];
