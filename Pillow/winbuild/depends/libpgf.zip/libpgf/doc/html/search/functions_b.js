var searchData=
[
  ['numberofbitplanes',['NumberOfBitplanes',['../classCEncoder_1_1CMacroBlock.html#a152834c140a4fcf478a2295eb247f4d4',1,'CEncoder::CMacroBlock']]],
  ['numberofwords',['NumberOfWords',['../BitStream_8h.html#aec0f6865df9443d08000c0fe4d446031',1,'BitStream.h']]]
];
