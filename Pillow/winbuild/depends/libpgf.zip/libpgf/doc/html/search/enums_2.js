var searchData=
[
  ['userdatapolicy',['UserdataPolicy',['../PGFtypes_8h.html#a0e70eeba0994fafcbfe6cbea3a734096',1,'PGFtypes.h']]]
];
