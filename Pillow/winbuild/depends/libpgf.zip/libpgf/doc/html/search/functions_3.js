var searchData=
[
  ['decodebuffer',['DecodeBuffer',['../classCDecoder.html#a78b5590168027919fcdba0ee9cbe2610',1,'CDecoder']]],
  ['decodeinterleaved',['DecodeInterleaved',['../classCDecoder.html#a7112215e28ac56d75bdf4a5786f57a34',1,'CDecoder']]],
  ['decomposebitplane',['DecomposeBitplane',['../classCEncoder_1_1CMacroBlock.html#a171a6f1d0d6297823542acc3cb43338a',1,'CEncoder::CMacroBlock']]],
  ['dequantize',['Dequantize',['../classCSubband.html#a45102bab9eee9b4e2beeea105712f292',1,'CSubband']]],
  ['dequantizevalue',['DequantizeValue',['../classCDecoder.html#acccce19e51f507dedbd564f2ce5c72e7',1,'CDecoder']]],
  ['destroy',['Destroy',['../classCPGFImage.html#a4a3e55e2e2d8ddf79506769feb8938ec',1,'CPGFImage::Destroy()'],['../classCWaveletTransform.html#a72c1bc79111534886187fcf2ac4cebea',1,'CWaveletTransform::Destroy()']]],
  ['downsample',['Downsample',['../classCPGFImage.html#a1db75413dfdc6f752088a53de0e6b998',1,'CPGFImage']]]
];
