var searchData=
[
  ['importbitmap',['ImportBitmap',['../classCPGFImage.html#a3c0895f4738c5222de1920c941a71541',1,'CPGFImage']]],
  ['importissupported',['ImportIsSupported',['../classCPGFImage.html#a5c32194271d4e115b8f5c7fdfc1670a5',1,'CPGFImage']]],
  ['importyuv',['ImportYUV',['../classCPGFImage.html#a5685c45a74b14b9f12ee2d81f49718f3',1,'CPGFImage']]],
  ['init',['Init',['../classCPGFImage.html#ab32b4053e41cc205cce45be8045e603b',1,'CPGFImage::Init()'],['../classCEncoder_1_1CMacroBlock.html#af3ecc039cc0e3000b394c15265107b38',1,'CEncoder::CMacroBlock::Init()']]],
  ['initbuffpos',['InitBuffPos',['../classCSubband.html#a1a5bca84a7ceb1ed6dbe417f8d6836ba',1,'CSubband']]],
  ['initialize',['Initialize',['../classCSubband.html#a5bdfe417903304a7b7348feb65904839',1,'CSubband']]],
  ['initsubbands',['InitSubbands',['../classCWaveletTransform.html#a4d03868a4bb8688235d41d6b1d7a97de',1,'CWaveletTransform']]],
  ['interleavedtosubbands',['InterleavedToSubbands',['../classCWaveletTransform.html#a7e926fe30c00e2bfa23f00a28a393f43',1,'CWaveletTransform']]],
  ['inverserow',['InverseRow',['../classCWaveletTransform.html#a1a39a469fd695c50efc42d744689982d',1,'CWaveletTransform']]],
  ['inversetransform',['InverseTransform',['../classCWaveletTransform.html#a26a70797c2a0db893876b75d131f420c',1,'CWaveletTransform']]],
  ['ioexception',['IOException',['../structIOException.html#ad1e8e7e09716ddc197a23611250fa180',1,'IOException::IOException()'],['../structIOException.html#a376ee2ee1fd67ef6de01e64ff142badb',1,'IOException::IOException(OSError err)']]],
  ['iscompletelyread',['IsCompletelyRead',['../classCDecoder_1_1CMacroBlock.html#a0425cb162ca41e04f6ae0886a62b3cc9',1,'CDecoder::CMacroBlock']]],
  ['isfullyread',['IsFullyRead',['../classCPGFImage.html#a3b6f8f9c75dd377a3cd6bf1e07e68531',1,'CPGFImage']]],
  ['isinside',['IsInside',['../structPGFRect.html#a3bf955a2a3e56756776391ed71d1de80',1,'PGFRect']]],
  ['isopen',['IsOpen',['../classCPGFImage.html#a73a46482fbfc549f8baa485c9b09f67a',1,'CPGFImage']]],
  ['isvalid',['IsValid',['../classCPGFStream.html#abf99169c9bcf0feb57edc55cec215b95',1,'CPGFStream::IsValid()'],['../classCPGFFileStream.html#a999b6c0ebc670ea58f5e34729e7f323a',1,'CPGFFileStream::IsValid()'],['../classCPGFMemoryStream.html#a5eb1f2ee69815d63fa764b100d883655',1,'CPGFMemoryStream::IsValid()']]]
];
