var searchData=
[
  ['bitplanedecode',['BitplaneDecode',['../classCDecoder_1_1CMacroBlock.html#a72899e368b29833bd485c4858b5ad7ef',1,'CDecoder::CMacroBlock']]],
  ['bitplaneencode',['BitplaneEncode',['../classCEncoder_1_1CMacroBlock.html#af95842ac15879ab2b3a9b5232bb4f1a5',1,'CEncoder::CMacroBlock']]],
  ['bpp',['BPP',['../classCPGFImage.html#ace9320cc25d748d77a7dfee759f01caa',1,'CPGFImage']]]
];
