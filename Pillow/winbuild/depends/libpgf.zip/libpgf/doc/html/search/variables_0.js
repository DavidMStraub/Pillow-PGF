var searchData=
[
  ['bottom',['bottom',['../structPGFRect.html#a7dc57925fee73fb4b3a1e3744971f579',1,'PGFRect']]],
  ['bpp',['bpp',['../structPGFHeader.html#aedea199e29cd6c404c82ab97c67e46b4',1,'PGFHeader']]],
  ['buffersize',['bufferSize',['../structROIBlockHeader_1_1RBH.html#af0c3de8c247b06116a9d84d2f9515762',1,'ROIBlockHeader::RBH']]]
];
