var searchData=
[
  ['bufferlen',['BufferLen',['../Decoder_8h.html#a309eafbca7ed5953ef9102861479f4ed',1,'BufferLen():&#160;Decoder.h'],['../Encoder_8h.html#a309eafbca7ed5953ef9102861479f4ed',1,'BufferLen():&#160;Encoder.h']]],
  ['buffersize',['BufferSize',['../PGFtypes_8h.html#aa362edf6db9662acf6ef958a6db19c35',1,'PGFtypes.h']]]
];
