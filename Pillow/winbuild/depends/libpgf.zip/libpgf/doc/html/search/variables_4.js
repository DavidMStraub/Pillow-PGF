var searchData=
[
  ['height',['height',['../structPGFHeader.html#a7262335e99ca409759e1aa8c0f0164b1',1,'PGFHeader']]],
  ['hsize',['hSize',['../structPGFPreHeader.html#a71b1463b71b722459dad25a3ef0b492b',1,'PGFPreHeader']]]
];
