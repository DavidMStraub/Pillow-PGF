var searchData=
[
  ['orientation',['Orientation',['../PGFtypes_8h.html#a871118a09520247c78a71ecd7b0abd58',1,'PGFtypes.h']]]
];
