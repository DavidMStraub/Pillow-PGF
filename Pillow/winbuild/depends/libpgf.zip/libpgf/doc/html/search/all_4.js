var searchData=
[
  ['datat',['DataT',['../PGFtypes_8h.html#acb1ee3f52ccfad782dcaa0abd79e5d05',1,'PGFtypes.h']]],
  ['datatsize',['DataTSize',['../PGFtypes_8h.html#adbb49c2b6ab931f68f08a8dc1141727d',1,'PGFtypes.h']]],
  ['decodebuffer',['DecodeBuffer',['../classCDecoder.html#a78b5590168027919fcdba0ee9cbe2610',1,'CDecoder']]],
  ['decodeinterleaved',['DecodeInterleaved',['../classCDecoder.html#a7112215e28ac56d75bdf4a5786f57a34',1,'CDecoder']]],
  ['decoder_2ecpp',['Decoder.cpp',['../Decoder_8cpp.html',1,'']]],
  ['decoder_2eh',['Decoder.h',['../Decoder_8h.html',1,'']]],
  ['decomposebitplane',['DecomposeBitplane',['../classCEncoder_1_1CMacroBlock.html#a171a6f1d0d6297823542acc3cb43338a',1,'CEncoder::CMacroBlock']]],
  ['dequantize',['Dequantize',['../classCSubband.html#a45102bab9eee9b4e2beeea105712f292',1,'CSubband']]],
  ['dequantizevalue',['DequantizeValue',['../classCDecoder.html#acccce19e51f507dedbd564f2ce5c72e7',1,'CDecoder']]],
  ['destroy',['Destroy',['../classCPGFImage.html#a4a3e55e2e2d8ddf79506769feb8938ec',1,'CPGFImage::Destroy()'],['../classCWaveletTransform.html#a72c1bc79111534886187fcf2ac4cebea',1,'CWaveletTransform::Destroy()']]],
  ['downsample',['Downsample',['../classCPGFImage.html#a1db75413dfdc6f752088a53de0e6b998',1,'CPGFImage']]],
  ['downsamplethreshold',['DownsampleThreshold',['../PGFtypes_8h.html#ac3fdd6d7d71ed50f3b7365d5bc287cda',1,'PGFtypes.h']]],
  ['dwwidth',['DWWIDTH',['../PGFplatform_8h.html#ac0b68f6649b541591637d4a0c3801411',1,'PGFplatform.h']]],
  ['dwwidthbits',['DWWIDTHBITS',['../PGFplatform_8h.html#a5e4b038d49a5b8169c4af56c80ee5ac2',1,'PGFplatform.h']]],
  ['dwwidthrest',['DWWIDTHREST',['../PGFplatform_8h.html#adb44cec3b215759869d8e41b02ebaf6d',1,'PGFplatform.h']]]
];
