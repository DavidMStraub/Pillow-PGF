var searchData=
[
  ['level',['Level',['../classCPGFImage.html#a4619eb255afd03dabea2b0afbe6e0d94',1,'CPGFImage']]],
  ['levels',['Levels',['../classCPGFImage.html#ab3678d05c031dc4cbf5451e7f4f6bdf3',1,'CPGFImage']]],
  ['levelsizeh',['LevelSizeH',['../classCPGFImage.html#a96e7712f6033810f386a23f2faec0037',1,'CPGFImage']]],
  ['levelsizel',['LevelSizeL',['../classCPGFImage.html#ad7e2f885a059a39ca15a47ecb497833b',1,'CPGFImage']]]
];
