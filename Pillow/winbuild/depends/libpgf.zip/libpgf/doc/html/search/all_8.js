var searchData=
[
  ['headersize',['HeaderSize',['../PGFtypes_8h.html#a36882df0caa9057f3144aeb429a2d468',1,'PGFtypes.h']]],
  ['height',['Height',['../classCPGFImage.html#aab401a02923fc9161e890602f26c829e',1,'CPGFImage::Height()'],['../structPGFRect.html#a139b8bb60ea476cd14856476b2d37b0f',1,'PGFRect::Height()'],['../structPGFHeader.html#a7262335e99ca409759e1aa8c0f0164b1',1,'PGFHeader::height()']]],
  ['hh',['HH',['../PGFtypes_8h.html#a871118a09520247c78a71ecd7b0abd58adb4fbeed3fdce116b66baef714de6667',1,'PGFtypes.h']]],
  ['hl',['HL',['../PGFtypes_8h.html#a871118a09520247c78a71ecd7b0abd58aad18f3a107c5bc020bff8923ad43bbc1',1,'PGFtypes.h']]],
  ['hsize',['hSize',['../structPGFPreHeader.html#a71b1463b71b722459dad25a3ef0b492b',1,'PGFPreHeader']]]
];
