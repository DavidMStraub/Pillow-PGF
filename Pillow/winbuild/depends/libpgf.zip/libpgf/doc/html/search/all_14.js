var searchData=
[
  ['val',['val',['../unionROIBlockHeader.html#a84e2058de6eb0cb75f6d5b0388915494',1,'ROIBlockHeader']]],
  ['version',['version',['../structPGFMagicVersion.html#aa7ff5e50537cac9dd4c62d4c8982d09d',1,'PGFMagicVersion::version()'],['../structPGFHeader.html#a637699477fb97e62d8cc3c102fac1fbb',1,'PGFHeader::version()'],['../classCPGFImage.html#aa872f5010f55a3bc696706d259b52051',1,'CPGFImage::Version()']]],
  ['version2',['Version2',['../PGFtypes_8h.html#aa67f9095ea51d6ffdc580497bc70d6ce',1,'PGFtypes.h']]],
  ['version5',['Version5',['../PGFtypes_8h.html#a99612b00f7a591c93702520453567913',1,'PGFtypes.h']]],
  ['version6',['Version6',['../PGFtypes_8h.html#ab75c5e81917cb1ee3ec6396af51aff27',1,'PGFtypes.h']]],
  ['version7',['Version7',['../PGFtypes_8h.html#a7ec86ea7c424e6e90984fb8ef0e3ada0',1,'PGFtypes.h']]]
];
