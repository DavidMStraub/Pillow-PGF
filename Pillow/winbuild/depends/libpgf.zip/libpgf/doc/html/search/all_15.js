var searchData=
[
  ['wavelettransform_2ecpp',['WaveletTransform.cpp',['../WaveletTransform_8cpp.html',1,'']]],
  ['wavelettransform_2eh',['WaveletTransform.h',['../WaveletTransform_8h.html',1,'']]],
  ['week',['week',['../structPGFVersionNumber.html#a4391fcda3b38f0514dff17ea5c0ea81e',1,'PGFVersionNumber']]],
  ['width',['width',['../structPGFHeader.html#a766a68c3284c2ae6d2f54c82e7350ed9',1,'PGFHeader::width()'],['../classCPGFImage.html#a327590f3bda3700649fbc7c99f8206f2',1,'CPGFImage::Width()'],['../structPGFRect.html#a70d366f5adc104f7037b627f35a18729',1,'PGFRect::Width()']]],
  ['wordbytes',['WordBytes',['../PGFplatform_8h.html#abeb1344b9026903d401004c4493a243f',1,'PGFplatform.h']]],
  ['wordbyteslog',['WordBytesLog',['../PGFplatform_8h.html#a53b5e7fa0f08ce6c609217017ae3dc5c',1,'PGFplatform.h']]],
  ['wordbytesmask',['WordBytesMask',['../PGFplatform_8h.html#ab2dd67aefd8e74b44ea5bd9b79cb3de7',1,'PGFplatform.h']]],
  ['wordmask',['WordMask',['../PGFplatform_8h.html#a02921b6e5430c4b9de7181d802125bdc',1,'PGFplatform.h']]],
  ['wordwidth',['WordWidth',['../PGFplatform_8h.html#abeb69f096b599bae58cbc58ba48250a5',1,'PGFplatform.h']]],
  ['wordwidthlog',['WordWidthLog',['../PGFplatform_8h.html#a5e75d7d14aaea5860c612758ef77b687',1,'PGFplatform.h']]],
  ['write',['Write',['../classCPGFImage.html#acd13d233dceaeefce3def7d71ebf4f82',1,'CPGFImage::Write(CPGFStream *stream, UINT32 *nWrittenBytes=nullptr, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFImage.html#a9a0ef3ad10c8a14b2b9a8d6153387ffe',1,'CPGFImage::Write(int level, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFStream.html#a0a46ae977995134787219288f4123134',1,'CPGFStream::Write()'],['../classCPGFFileStream.html#a28a060662951edf72f7739ba575c9fff',1,'CPGFFileStream::Write()'],['../classCPGFMemoryStream.html#a627161d30d8d10fc306f50ea9c37f1a5',1,'CPGFMemoryStream::Write()']]],
  ['writebuffer',['WriteBuffer',['../classCSubband.html#a3bebc017649e7dbef182efe3cbe17965',1,'CSubband']]],
  ['writeheader',['WriteHeader',['../classCPGFImage.html#a1d853cd049417f0afc9a868664d7134d',1,'CPGFImage']]],
  ['writeimage',['WriteImage',['../classCPGFImage.html#a0f0657eaf1a62ab14c01834e5c7adb07',1,'CPGFImage']]],
  ['writelevel',['WriteLevel',['../classCPGFImage.html#a1075a31893ee4ea2c686f5b471dd3664',1,'CPGFImage']]],
  ['writelevellength',['WriteLevelLength',['../classCEncoder.html#ad29dd5328d1198a672599034e7315922',1,'CEncoder']]],
  ['writemacroblock',['WriteMacroBlock',['../classCEncoder.html#ab64923561baadef47bea653e9a52238e',1,'CEncoder']]],
  ['writevalue',['WriteValue',['../classCEncoder.html#a56e4a13cb14295ffb016e9efef5ebcd8',1,'CEncoder']]]
];
