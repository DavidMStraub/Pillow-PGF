var searchData=
[
  ['wavelettransform_2ecpp',['WaveletTransform.cpp',['../WaveletTransform_8cpp.html',1,'']]],
  ['wavelettransform_2eh',['WaveletTransform.h',['../WaveletTransform_8h.html',1,'']]]
];
