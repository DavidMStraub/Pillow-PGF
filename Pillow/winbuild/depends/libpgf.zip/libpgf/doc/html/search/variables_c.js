var searchData=
[
  ['val',['val',['../unionROIBlockHeader.html#a84e2058de6eb0cb75f6d5b0388915494',1,'ROIBlockHeader']]],
  ['version',['version',['../structPGFMagicVersion.html#aa7ff5e50537cac9dd4c62d4c8982d09d',1,'PGFMagicVersion::version()'],['../structPGFHeader.html#a637699477fb97e62d8cc3c102fac1fbb',1,'PGFHeader::version()']]]
];
