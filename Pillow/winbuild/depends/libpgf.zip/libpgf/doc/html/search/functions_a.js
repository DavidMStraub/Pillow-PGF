var searchData=
[
  ['maxchanneldepth',['MaxChannelDepth',['../classCPGFImage.html#a368601b5942e4406cdb87120406ff075',1,'CPGFImage']]],
  ['mode',['Mode',['../classCPGFImage.html#a8c60aabdcf2556e9a425052e7f5b5d30',1,'CPGFImage']]]
];
