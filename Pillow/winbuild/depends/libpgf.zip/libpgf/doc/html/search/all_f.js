var searchData=
[
  ['quality',['Quality',['../classCPGFImage.html#a6d8ca06237591aae49d7f25278067c63',1,'CPGFImage::Quality()'],['../structPGFHeader.html#ac314a16d5984aea88f4a5ff38f49c08b',1,'PGFHeader::quality()']]],
  ['quantize',['Quantize',['../classCSubband.html#a5de71c37eb00e5e5dad3fe5e38b81ced',1,'CSubband']]]
];
