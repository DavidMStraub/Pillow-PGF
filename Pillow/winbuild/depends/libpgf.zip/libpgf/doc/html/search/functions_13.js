var searchData=
[
  ['width',['Width',['../classCPGFImage.html#a327590f3bda3700649fbc7c99f8206f2',1,'CPGFImage::Width()'],['../structPGFRect.html#a70d366f5adc104f7037b627f35a18729',1,'PGFRect::Width()']]],
  ['write',['Write',['../classCPGFImage.html#acd13d233dceaeefce3def7d71ebf4f82',1,'CPGFImage::Write(CPGFStream *stream, UINT32 *nWrittenBytes=nullptr, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFImage.html#a9a0ef3ad10c8a14b2b9a8d6153387ffe',1,'CPGFImage::Write(int level, CallbackPtr cb=nullptr, void *data=nullptr)'],['../classCPGFStream.html#a0a46ae977995134787219288f4123134',1,'CPGFStream::Write()'],['../classCPGFFileStream.html#a28a060662951edf72f7739ba575c9fff',1,'CPGFFileStream::Write()'],['../classCPGFMemoryStream.html#a627161d30d8d10fc306f50ea9c37f1a5',1,'CPGFMemoryStream::Write()']]],
  ['writebuffer',['WriteBuffer',['../classCSubband.html#a3bebc017649e7dbef182efe3cbe17965',1,'CSubband']]],
  ['writeheader',['WriteHeader',['../classCPGFImage.html#a1d853cd049417f0afc9a868664d7134d',1,'CPGFImage']]],
  ['writeimage',['WriteImage',['../classCPGFImage.html#a0f0657eaf1a62ab14c01834e5c7adb07',1,'CPGFImage']]],
  ['writelevel',['WriteLevel',['../classCPGFImage.html#a1075a31893ee4ea2c686f5b471dd3664',1,'CPGFImage']]],
  ['writelevellength',['WriteLevelLength',['../classCEncoder.html#ad29dd5328d1198a672599034e7315922',1,'CEncoder']]],
  ['writemacroblock',['WriteMacroBlock',['../classCEncoder.html#ab64923561baadef47bea653e9a52238e',1,'CEncoder']]],
  ['writevalue',['WriteValue',['../classCEncoder.html#a56e4a13cb14295ffb016e9efef5ebcd8',1,'CEncoder']]]
];
