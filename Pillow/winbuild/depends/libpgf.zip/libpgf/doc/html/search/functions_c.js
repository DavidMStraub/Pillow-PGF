var searchData=
[
  ['open',['Open',['../classCPGFImage.html#adbe9092b915a2c5b2361f4db186b991c',1,'CPGFImage']]]
];
