var searchData=
[
  ['magicversionsize',['MagicVersionSize',['../PGFtypes_8h.html#a7b1bd3bd3f41e82f5e4c3f642079c122',1,'PGFtypes.h']]],
  ['makeu64',['MAKEU64',['../BitStream_8h.html#ac84b4ebee770a8dc0a8471a3cdaf05af',1,'BitStream.h']]],
  ['maxbitplanes',['MaxBitPlanes',['../PGFtypes_8h.html#ae0625b6a0d1a8187599a680c6b559860',1,'PGFtypes.h']]],
  ['maxbitplaneslog',['MaxBitPlanesLog',['../PGFtypes_8h.html#a0acbc7f581c1eceef6a70713308987d5',1,'PGFtypes.h']]],
  ['maxchannels',['MaxChannels',['../PGFtypes_8h.html#a94219182f88d4dbed1021ed04db75e41',1,'PGFtypes.h']]],
  ['maxcodelen',['MaxCodeLen',['../Decoder_8cpp.html#add8bd7fd3fbb318e2f76b4ae33cf6020',1,'MaxCodeLen():&#160;Decoder.cpp'],['../Encoder_8cpp.html#add8bd7fd3fbb318e2f76b4ae33cf6020',1,'MaxCodeLen():&#160;Encoder.cpp']]],
  ['maxlevel',['MaxLevel',['../PGFtypes_8h.html#a2468e509eae9683e25af403249b743a3',1,'PGFtypes.h']]],
  ['maxquality',['MaxQuality',['../PGFtypes_8h.html#a70d2da7f475eb7f6564e75d64ee77ae4',1,'PGFtypes.h']]],
  ['maxuserdatasize',['MaxUserDataSize',['../PGFtypes_8h.html#a513fcd9e30f1a99d382b5c001499cdf5',1,'PGFtypes.h']]]
];
