var searchData=
[
  ['cacheduserdatalen',['cachedUserDataLen',['../structPGFPostHeader.html#a104e3ef6de85dfdbbd867a250fcd82d4',1,'PGFPostHeader']]],
  ['channels',['channels',['../structPGFHeader.html#abda7a5f282421cd7e789da62f657efa0',1,'PGFHeader']]],
  ['clut',['clut',['../structPGFPostHeader.html#a3a7faf3091c0faa2e508ecdeb54ea706',1,'PGFPostHeader']]]
];
