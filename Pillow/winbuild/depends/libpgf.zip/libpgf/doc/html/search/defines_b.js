var searchData=
[
  ['stringize',['STRINGIZE',['../PGFtypes_8h.html#a9301916f6c8ae438b0cf7c6769b34128',1,'PGFtypes.h']]],
  ['stringize_5fnx',['STRINGIZE_NX',['../PGFtypes_8h.html#af90e7cb64f23452c7c57b9b231bace78',1,'PGFtypes.h']]]
];
