var searchData=
[
  ['bitplanedecode',['BitplaneDecode',['../classCDecoder_1_1CMacroBlock.html#a72899e368b29833bd485c4858b5ad7ef',1,'CDecoder::CMacroBlock']]],
  ['bitplaneencode',['BitplaneEncode',['../classCEncoder_1_1CMacroBlock.html#af95842ac15879ab2b3a9b5232bb4f1a5',1,'CEncoder::CMacroBlock']]],
  ['bitstream_2eh',['BitStream.h',['../BitStream_8h.html',1,'']]],
  ['bottom',['bottom',['../structPGFRect.html#a7dc57925fee73fb4b3a1e3744971f579',1,'PGFRect']]],
  ['bpp',['BPP',['../classCPGFImage.html#ace9320cc25d748d77a7dfee759f01caa',1,'CPGFImage::BPP()'],['../structPGFHeader.html#aedea199e29cd6c404c82ab97c67e46b4',1,'PGFHeader::bpp()']]],
  ['bufferlen',['BufferLen',['../Decoder_8h.html#a309eafbca7ed5953ef9102861479f4ed',1,'BufferLen():&#160;Decoder.h'],['../Encoder_8h.html#a309eafbca7ed5953ef9102861479f4ed',1,'BufferLen():&#160;Encoder.h']]],
  ['buffersize',['bufferSize',['../structROIBlockHeader_1_1RBH.html#af0c3de8c247b06116a9d84d2f9515762',1,'ROIBlockHeader::RBH::bufferSize()'],['../PGFtypes_8h.html#aa362edf6db9662acf6ef958a6db19c35',1,'BufferSize():&#160;PGFtypes.h']]]
];
