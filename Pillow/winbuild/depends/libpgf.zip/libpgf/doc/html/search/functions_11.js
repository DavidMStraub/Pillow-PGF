var searchData=
[
  ['updatelevellength',['UpdateLevelLength',['../classCEncoder.html#a93d5e9bf075e804eb9626d4b0292c4dd',1,'CEncoder']]],
  ['updatepostheadersize',['UpdatePostHeaderSize',['../classCPGFImage.html#a921e1ec08da8ddf6ab4d5657e5610fee',1,'CPGFImage::UpdatePostHeaderSize()'],['../classCEncoder.html#adcacefab75d6ab0e562d854f31d242ff',1,'CEncoder::UpdatePostHeaderSize()']]],
  ['usedbitsperchannel',['UsedBitsPerChannel',['../classCPGFImage.html#a6cc4f75843c3c15f573aaa0131649b10',1,'CPGFImage']]]
];
