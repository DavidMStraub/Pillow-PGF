var searchData=
[
  ['nsubbands',['NSubbands',['../PGFtypes_8h.html#a0cf7b93e79e7ebfc148bc9dff30d8cd1',1,'PGFtypes.h']]]
];
