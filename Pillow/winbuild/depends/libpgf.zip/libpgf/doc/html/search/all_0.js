var searchData=
[
  ['_5f_5fmax',['__max',['../PGFplatform_8h.html#af643213a7d426b69429d1430cef4ecbb',1,'PGFplatform.h']]],
  ['_5f_5fmin',['__min',['../PGFplatform_8h.html#ad6d0138bf7e2cdaabeedc3fea40767ad',1,'PGFplatform.h']]],
  ['_5f_5fpgf32support_5f_5f',['__PGF32SUPPORT__',['../PGFplatform_8h.html#aa78b4644e74419b9844cc268b0b97345',1,'PGFplatform.h']]],
  ['_5f_5fpgfroisupport_5f_5f',['__PGFROISUPPORT__',['../PGFplatform_8h.html#a96e10919059743496c33ac08997de3a5',1,'PGFplatform.h']]],
  ['_5f_5fval',['__VAL',['../PGFplatform_8h.html#ab45d30e0f7f4c42f39a63f436cb16f52',1,'PGFplatform.h']]]
];
