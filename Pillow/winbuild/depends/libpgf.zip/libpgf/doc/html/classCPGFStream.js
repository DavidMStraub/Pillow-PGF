var classCPGFStream =
[
    [ "CPGFStream", "classCPGFStream.html#a2384e79147a1c375e00722b1ef038121", null ],
    [ "~CPGFStream", "classCPGFStream.html#a32718570401ef16b8f778fa08cdb6a7a", null ],
    [ "GetPos", "classCPGFStream.html#a841e109647ea77dd9e589ab00ef4aad8", null ],
    [ "IsValid", "classCPGFStream.html#abf99169c9bcf0feb57edc55cec215b95", null ],
    [ "Read", "classCPGFStream.html#afdc81fe9b4d2d962b8112e50eace95a2", null ],
    [ "SetPos", "classCPGFStream.html#a69be67d4b04cd056c4f74d8147349a16", null ],
    [ "Write", "classCPGFStream.html#a0a46ae977995134787219288f4123134", null ]
];