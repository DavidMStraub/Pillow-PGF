var structPGFPostHeader =
[
    [ "cachedUserDataLen", "structPGFPostHeader.html#a104e3ef6de85dfdbbd867a250fcd82d4", null ],
    [ "clut", "structPGFPostHeader.html#a3a7faf3091c0faa2e508ecdeb54ea706", null ],
    [ "userData", "structPGFPostHeader.html#aeeb6e57e8343eb3d42406f0baf3ae6e1", null ],
    [ "userDataLen", "structPGFPostHeader.html#a0fb630d6cd14ed865dd5fe20227279f2", null ]
];