var structPGFRect =
[
    [ "PGFRect", "structPGFRect.html#a5f161a099003b7ffb7d06fd295682c59", null ],
    [ "PGFRect", "structPGFRect.html#abf81fef0acecca448c6f9f1b1c44f186", null ],
    [ "Height", "structPGFRect.html#a139b8bb60ea476cd14856476b2d37b0f", null ],
    [ "IsInside", "structPGFRect.html#a3bf955a2a3e56756776391ed71d1de80", null ],
    [ "Width", "structPGFRect.html#a70d366f5adc104f7037b627f35a18729", null ],
    [ "bottom", "structPGFRect.html#a7dc57925fee73fb4b3a1e3744971f579", null ],
    [ "left", "structPGFRect.html#ac3472e1dc20bc4b1584058376fd7b989", null ],
    [ "right", "structPGFRect.html#a9174d8de6b9018e0c4ef8e29a501b10a", null ],
    [ "top", "structPGFRect.html#a79df6810b4ffbf8c8825a67733d56913", null ]
];