var annotated =
[
    [ "CDecoder", "classCDecoder.html", "classCDecoder" ],
    [ "CEncoder", "classCEncoder.html", "classCEncoder" ],
    [ "CPGFFileStream", "classCPGFFileStream.html", "classCPGFFileStream" ],
    [ "CPGFImage", "classCPGFImage.html", "classCPGFImage" ],
    [ "CPGFMemoryStream", "classCPGFMemoryStream.html", "classCPGFMemoryStream" ],
    [ "CPGFStream", "classCPGFStream.html", "classCPGFStream" ],
    [ "CSubband", "classCSubband.html", "classCSubband" ],
    [ "CWaveletTransform", "classCWaveletTransform.html", "classCWaveletTransform" ],
    [ "IOException", "structIOException.html", "structIOException" ],
    [ "PGFHeader", "structPGFHeader.html", "structPGFHeader" ],
    [ "PGFMagicVersion", "structPGFMagicVersion.html", "structPGFMagicVersion" ],
    [ "PGFPostHeader", "structPGFPostHeader.html", "structPGFPostHeader" ],
    [ "PGFPreHeader", "structPGFPreHeader.html", "structPGFPreHeader" ],
    [ "PGFRect", "structPGFRect.html", "structPGFRect" ],
    [ "PGFVersionNumber", "structPGFVersionNumber.html", "structPGFVersionNumber" ],
    [ "ROIBlockHeader", "unionROIBlockHeader.html", "unionROIBlockHeader" ]
];