var structPGFMagicVersion =
[
    [ "magic", "structPGFMagicVersion.html#a8b27eabb723f35b4fdb9e357e69b334b", null ],
    [ "version", "structPGFMagicVersion.html#aa7ff5e50537cac9dd4c62d4c8982d09d", null ]
];