var classCEncoder_1_1CMacroBlock =
[
    [ "CMacroBlock", "classCEncoder_1_1CMacroBlock.html#a70f3cc1cb204a4bcce871bf6b5b134f6", null ],
    [ "BitplaneEncode", "classCEncoder_1_1CMacroBlock.html#af95842ac15879ab2b3a9b5232bb4f1a5", null ],
    [ "DecomposeBitplane", "classCEncoder_1_1CMacroBlock.html#a171a6f1d0d6297823542acc3cb43338a", null ],
    [ "GetBitAtPos", "classCEncoder_1_1CMacroBlock.html#a84aa40ee75fb9d993c0cec207b4092e3", null ],
    [ "Init", "classCEncoder_1_1CMacroBlock.html#af3ecc039cc0e3000b394c15265107b38", null ],
    [ "NumberOfBitplanes", "classCEncoder_1_1CMacroBlock.html#a152834c140a4fcf478a2295eb247f4d4", null ],
    [ "RLESigns", "classCEncoder_1_1CMacroBlock.html#a50637f0c6ccc3d29b10063204a55253b", null ],
    [ "m_codeBuffer", "classCEncoder_1_1CMacroBlock.html#a527667f1e0529ff577dcbe7f0aa38d77", null ],
    [ "m_codePos", "classCEncoder_1_1CMacroBlock.html#a6e15685fcab5aa06f0f5ed17312774c7", null ],
    [ "m_encoder", "classCEncoder_1_1CMacroBlock.html#adf5e8e4952216e6fdd189224618edd50", null ],
    [ "m_header", "classCEncoder_1_1CMacroBlock.html#aa5abc7cc9df3402a233367f0087168f8", null ],
    [ "m_lastLevelIndex", "classCEncoder_1_1CMacroBlock.html#a68163a823248889d9d407f4b0331245d", null ],
    [ "m_maxAbsValue", "classCEncoder_1_1CMacroBlock.html#a865f294ffa568a165224c2105bf1bb01", null ],
    [ "m_sigFlagVector", "classCEncoder_1_1CMacroBlock.html#a7acaa42598512b958d5e16b8bcded13b", null ],
    [ "m_value", "classCEncoder_1_1CMacroBlock.html#a139b60f3f0d76b9158573e4d897423d6", null ],
    [ "m_valuePos", "classCEncoder_1_1CMacroBlock.html#a7ab47e29ad9e3397869fdfb50b53e035", null ]
];