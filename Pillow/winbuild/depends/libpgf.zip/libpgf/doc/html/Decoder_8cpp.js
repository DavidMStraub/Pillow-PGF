var Decoder_8cpp =
[
    [ "CodeBufferBitLen", "Decoder_8cpp.html#abc1529b42b4ec49f6674b24b5b0d0a45", null ],
    [ "MaxCodeLen", "Decoder_8cpp.html#add8bd7fd3fbb318e2f76b4ae33cf6020", null ]
];