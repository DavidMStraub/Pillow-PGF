var classCPGFMemoryStream =
[
    [ "CPGFMemoryStream", "classCPGFMemoryStream.html#a04270a0cc3b62a272c11289931e91986", null ],
    [ "CPGFMemoryStream", "classCPGFMemoryStream.html#a7b1d3b9977b016ebbb077a233b461bd5", null ],
    [ "~CPGFMemoryStream", "classCPGFMemoryStream.html#ab562ed581dd1ed8364a41463b6da5006", null ],
    [ "GetBuffer", "classCPGFMemoryStream.html#a4cfd2eca6ce408dbc37c018cbed20424", null ],
    [ "GetBuffer", "classCPGFMemoryStream.html#ae6c636725895a016902ea76aeb5d9301", null ],
    [ "GetEOS", "classCPGFMemoryStream.html#adac05f8f6c35bb8b82cfeef431bc7171", null ],
    [ "GetPos", "classCPGFMemoryStream.html#a40556ef625e2bd49144281b3f6e1f0dd", null ],
    [ "GetSize", "classCPGFMemoryStream.html#a44170277f36028bbff876fd6ebaeef21", null ],
    [ "IsValid", "classCPGFMemoryStream.html#a5eb1f2ee69815d63fa764b100d883655", null ],
    [ "Read", "classCPGFMemoryStream.html#a4cf0499309d901fcdcd9282a7351d24d", null ],
    [ "Reinitialize", "classCPGFMemoryStream.html#afb1145a071e4156a4343c6203ad18b0c", null ],
    [ "SetEOS", "classCPGFMemoryStream.html#a0e295b7061f07f840580d36f7946f523", null ],
    [ "SetPos", "classCPGFMemoryStream.html#a28e8defe72f535c49535c40ffe2ad299", null ],
    [ "Write", "classCPGFMemoryStream.html#a627161d30d8d10fc306f50ea9c37f1a5", null ],
    [ "m_allocated", "classCPGFMemoryStream.html#ad067b8fcb304992bc8596d634fbbe20b", null ],
    [ "m_buffer", "classCPGFMemoryStream.html#a9d4c1baa334c288fba0f5e4fc9e9a31e", null ],
    [ "m_eos", "classCPGFMemoryStream.html#a7c0a47341ab8962728284db230b44203", null ],
    [ "m_pos", "classCPGFMemoryStream.html#a901356d38f0aee983fa19bff73727ec6", null ],
    [ "m_size", "classCPGFMemoryStream.html#a640b0fa8b5cfef4ea4d25adc7bf30ffa", null ]
];