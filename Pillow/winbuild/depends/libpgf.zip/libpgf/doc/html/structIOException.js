var structIOException =
[
    [ "IOException", "structIOException.html#ad1e8e7e09716ddc197a23611250fa180", null ],
    [ "IOException", "structIOException.html#a376ee2ee1fd67ef6de01e64ff142badb", null ],
    [ "error", "structIOException.html#a0bb5b188546419d80622e4e5ef951ec7", null ]
];