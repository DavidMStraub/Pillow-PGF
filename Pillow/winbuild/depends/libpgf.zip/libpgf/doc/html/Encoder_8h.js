var Encoder_8h =
[
    [ "CEncoder", "classCEncoder.html", "classCEncoder" ],
    [ "CMacroBlock", "classCEncoder_1_1CMacroBlock.html", "classCEncoder_1_1CMacroBlock" ],
    [ "BufferLen", "Encoder_8h.html#a309eafbca7ed5953ef9102861479f4ed", null ],
    [ "CodeBufferLen", "Encoder_8h.html#a05a74e73e6c734fcad194efbca053ed5", null ]
];