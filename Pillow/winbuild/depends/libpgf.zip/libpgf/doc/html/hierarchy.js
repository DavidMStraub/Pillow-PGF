var hierarchy =
[
    [ "CDecoder", "classCDecoder.html", null ],
    [ "CEncoder", "classCEncoder.html", null ],
    [ "CEncoder::CMacroBlock", "classCEncoder_1_1CMacroBlock.html", null ],
    [ "CDecoder::CMacroBlock", "classCDecoder_1_1CMacroBlock.html", null ],
    [ "CPGFImage", "classCPGFImage.html", null ],
    [ "CPGFStream", "classCPGFStream.html", [
      [ "CPGFFileStream", "classCPGFFileStream.html", null ],
      [ "CPGFMemoryStream", "classCPGFMemoryStream.html", null ]
    ] ],
    [ "CSubband", "classCSubband.html", null ],
    [ "CWaveletTransform", "classCWaveletTransform.html", null ],
    [ "IOException", "structIOException.html", null ],
    [ "PGFHeader", "structPGFHeader.html", null ],
    [ "PGFMagicVersion", "structPGFMagicVersion.html", [
      [ "PGFPreHeader", "structPGFPreHeader.html", null ]
    ] ],
    [ "PGFPostHeader", "structPGFPostHeader.html", null ],
    [ "PGFRect", "structPGFRect.html", null ],
    [ "PGFVersionNumber", "structPGFVersionNumber.html", null ],
    [ "ROIBlockHeader::RBH", "structROIBlockHeader_1_1RBH.html", null ],
    [ "ROIBlockHeader", "unionROIBlockHeader.html", null ]
];