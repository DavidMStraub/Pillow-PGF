var WaveletTransform_8h =
[
    [ "CWaveletTransform", "classCWaveletTransform.html", "classCWaveletTransform" ],
    [ "FilterSize", "WaveletTransform_8h.html#a93633fc816f186e990eabf5e8f20a40f", null ],
    [ "FilterSizeH", "WaveletTransform_8h.html#a7484fbd3691479d22e4794cdb0c5b8cb", null ],
    [ "FilterSizeL", "WaveletTransform_8h.html#a6dafe9e561957dbc2a08b8aadd5f80c3", null ]
];