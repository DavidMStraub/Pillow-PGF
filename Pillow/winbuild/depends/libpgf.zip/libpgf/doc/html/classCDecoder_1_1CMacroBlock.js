var classCDecoder_1_1CMacroBlock =
[
    [ "CMacroBlock", "classCDecoder_1_1CMacroBlock.html#aca6c25f512f637244f971e21f813f433", null ],
    [ "BitplaneDecode", "classCDecoder_1_1CMacroBlock.html#a72899e368b29833bd485c4858b5ad7ef", null ],
    [ "ComposeBitplane", "classCDecoder_1_1CMacroBlock.html#a580e46028e0104de8d6afab733c8b679", null ],
    [ "ComposeBitplaneRLD", "classCDecoder_1_1CMacroBlock.html#aa6e8f0dedcdeb9e592de7dde07b5025e", null ],
    [ "ComposeBitplaneRLD", "classCDecoder_1_1CMacroBlock.html#af7de96f745479ca3956f671a7f794489", null ],
    [ "IsCompletelyRead", "classCDecoder_1_1CMacroBlock.html#a0425cb162ca41e04f6ae0886a62b3cc9", null ],
    [ "SetBitAtPos", "classCDecoder_1_1CMacroBlock.html#a4bf1b6bc026f95ef4d93fbdfaf69f724", null ],
    [ "SetSign", "classCDecoder_1_1CMacroBlock.html#a7fd4539d524903d148ceb4de940d3194", null ],
    [ "m_codeBuffer", "classCDecoder_1_1CMacroBlock.html#ace0702d7f8281972b1db091248c3c80b", null ],
    [ "m_header", "classCDecoder_1_1CMacroBlock.html#a19247bd5e6073252c45abf9d33b44ee0", null ],
    [ "m_sigFlagVector", "classCDecoder_1_1CMacroBlock.html#af6931769654b397d6c3becae44e868b0", null ],
    [ "m_value", "classCDecoder_1_1CMacroBlock.html#a7722de1000647fb5a894db2e2f348bdd", null ],
    [ "m_valuePos", "classCDecoder_1_1CMacroBlock.html#a38f42e9e2d5ac8387db0122aecac79be", null ]
];