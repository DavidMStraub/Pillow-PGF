var classCPGFFileStream =
[
    [ "CPGFFileStream", "classCPGFFileStream.html#ae505bb374fe13a0b9cdac3b71ae414e2", null ],
    [ "CPGFFileStream", "classCPGFFileStream.html#ac429f9fa68a762203d727a6c0d586eec", null ],
    [ "~CPGFFileStream", "classCPGFFileStream.html#ac9da1053f6b3cb8f3e403060ff7a44ae", null ],
    [ "GetHandle", "classCPGFFileStream.html#a94046c82916ffeb6aa868f27f25b1c37", null ],
    [ "GetPos", "classCPGFFileStream.html#a9ec4715342add84461c62631101e1ce6", null ],
    [ "IsValid", "classCPGFFileStream.html#a999b6c0ebc670ea58f5e34729e7f323a", null ],
    [ "Read", "classCPGFFileStream.html#a3ff32003518e1d996cc8af33c5bbbfaf", null ],
    [ "SetPos", "classCPGFFileStream.html#a2460f1fdab77a44ddf24420139a50043", null ],
    [ "Write", "classCPGFFileStream.html#a28a060662951edf72f7739ba575c9fff", null ],
    [ "m_hFile", "classCPGFFileStream.html#a3e442cbf8c1a8f66d737c36ceb0c9f32", null ]
];