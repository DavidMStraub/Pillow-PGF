var structPGFHeader =
[
    [ "PGFHeader", "structPGFHeader.html#acdc6457170d5adce40fa0c05d0c09ed2", null ],
    [ "bpp", "structPGFHeader.html#aedea199e29cd6c404c82ab97c67e46b4", null ],
    [ "channels", "structPGFHeader.html#abda7a5f282421cd7e789da62f657efa0", null ],
    [ "height", "structPGFHeader.html#a7262335e99ca409759e1aa8c0f0164b1", null ],
    [ "mode", "structPGFHeader.html#a3ddaf075db8ee812ad688d9ed39e0698", null ],
    [ "nLevels", "structPGFHeader.html#a963890fa1e02a517923f9d0bf0d7e9eb", null ],
    [ "quality", "structPGFHeader.html#ac314a16d5984aea88f4a5ff38f49c08b", null ],
    [ "usedBitsPerChannel", "structPGFHeader.html#abddcc9ee6e17690986cf77a6d16aceb6", null ],
    [ "version", "structPGFHeader.html#a637699477fb97e62d8cc3c102fac1fbb", null ],
    [ "width", "structPGFHeader.html#a766a68c3284c2ae6d2f54c82e7350ed9", null ]
];