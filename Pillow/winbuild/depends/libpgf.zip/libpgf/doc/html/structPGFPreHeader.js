var structPGFPreHeader =
[
    [ "hSize", "structPGFPreHeader.html#a71b1463b71b722459dad25a3ef0b492b", null ],
    [ "magic", "structPGFPreHeader.html#a8b27eabb723f35b4fdb9e357e69b334b", null ],
    [ "version", "structPGFPreHeader.html#aa7ff5e50537cac9dd4c62d4c8982d09d", null ]
];